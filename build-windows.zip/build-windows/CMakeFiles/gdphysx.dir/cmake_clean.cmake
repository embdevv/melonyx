file(REMOVE_RECURSE
  "CMakeFiles/gdphysx.dir/src/main.cpp.obj"
  "CMakeFiles/gdphysx.dir/src/main.cpp.obj.d"
  "gdphysx.exe"
  "gdphysx.pdb"
  "libgdphysx.dll.a"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/gdphysx.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
