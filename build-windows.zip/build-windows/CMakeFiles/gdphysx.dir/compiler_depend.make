# Empty compiler generated dependencies file for gdphysx.
# This may be replaced when dependencies are built.
