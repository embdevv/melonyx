file(REMOVE_RECURSE
  "CMakeFiles/glad_gl_core_46.dir/gladsources/glad_gl_core_46/src/gl.c.obj"
  "CMakeFiles/glad_gl_core_46.dir/gladsources/glad_gl_core_46/src/gl.c.obj.d"
  "gladsources/glad_gl_core_46/args.txt"
  "gladsources/glad_gl_core_46/include/KHR/khrplatform.h"
  "gladsources/glad_gl_core_46/include/glad/gl.h"
  "gladsources/glad_gl_core_46/src/gl.c"
  "libglad_gl_core_46.a"
  "libglad_gl_core_46.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/glad_gl_core_46.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
