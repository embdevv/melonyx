set(CMAKE_HOST_SYSTEM "Linux-7.0.5-2-cachyos")
set(CMAKE_HOST_SYSTEM_NAME "Linux")
set(CMAKE_HOST_SYSTEM_VERSION "7.0.5-2-cachyos")
set(CMAKE_HOST_SYSTEM_PROCESSOR "x86_64")

include("/home/embdev/Documents/GitHub/gdphysx/cmake/windows-toolchain.cmake")

set(CMAKE_SYSTEM "Windows")
set(CMAKE_SYSTEM_NAME "Windows")
set(CMAKE_SYSTEM_VERSION "")
set(CMAKE_SYSTEM_PROCESSOR "x86_64")

set(CMAKE_CROSSCOMPILING "TRUE")

set(CMAKE_SYSTEM_LOADED 1)
